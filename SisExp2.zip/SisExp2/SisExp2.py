from rule_engine import Rule, Context


class Cliente:
    def __init__(self, puntuacion_crediticia, ingresos_mensuales, cuota_prestamo, dti, tipo_empleo, garantias,
                 historial_prestamos):
        self.puntuacion_crediticia = puntuacion_crediticia
        self.ingresos_mensuales = ingresos_mensuales
        self.cuota_prestamo = cuota_prestamo
        self.dti = dti
        self.tipo_empleo = tipo_empleo
        self.garantias = garantias
        self.historial_prestamos = historial_prestamos
        self.decision = "En evaluación"

    def evaluar(self):
        contexto = Context(default_value=None)
        reglas = [
            Rule(
                "puntuacion_crediticia >= 750 and ingresos_mensuales > 3 * cuota_prestamo and dti < 30 and tipo_empleo == 'fijo_5' and garantias == 'alta' and historial_prestamos == 'bueno'",
                contexto),
            Rule(
                "puntuacion_crediticia >= 600 and puntuacion_crediticia <= 750 and ingresos_mensuales >= 1.5 * cuota_prestamo and ingresos_mensuales <= 3 * cuota_prestamo and dti >= 30 and dti <= 50 and tipo_empleo == 'fijo_menos_5' and garantias == 'media' and historial_prestamos == 'regular'",
                contexto),
            Rule(
                "puntuacion_crediticia < 600 or ingresos_mensuales < 1.5 * cuota_prestamo or dti > 50 or tipo_empleo == 'temporal' or garantias == 'baja' or historial_prestamos == 'malo'",
                contexto)
        ]

        if reglas[0].evaluate(self.__dict__):
            self.decision = "Aprobado"
        elif reglas[1].evaluate(self.__dict__):
            self.decision = "Aprobación Condicional"
        elif reglas[2].evaluate(self.__dict__):
            self.decision = "Rechazado"


if __name__ == "__main__":
    puntuacion_crediticia = int(input("Ingrese su puntuación crediticia: "))
    ingresos_mensuales = float(input("Ingrese sus ingresos mensuales: "))
    cuota_prestamo = float(input("Ingrese la cuota del préstamo: "))
    dti = float(input("Ingrese su relación Deuda/Ingreso en porcentaje: "))
    tipo_empleo = input("Ingrese su tipo de empleo (fijo_5, fijo_menos_5, temporal): ")
    garantias = input("Ingrese el nivel de garantías presentadas (alta, media, baja): ")
    historial_prestamos = input("Ingrese su historial de préstamos (bueno, regular, malo): ")

    cliente = Cliente(puntuacion_crediticia, ingresos_mensuales, cuota_prestamo, dti, tipo_empleo, garantias,
                      historial_prestamos)
    cliente.evaluar()
    print(f"Decisión sobre el préstamo: {cliente.decision}")

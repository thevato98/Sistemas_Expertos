from rule_engine import Rule


# Definición de la clase Cliente para almacenar la información
class Cliente:
    def __init__(self, nombre, edad, enfermedades_cronicas=False, obesidad=False,
                 estilo_vida_saludable=False, enfermedades_hereditarias=False,
                 fumador=False, alcohol_excesivo=False, deportista=False,
                 trabajo_alto_riesgo=False, polizas_previas_sin_problemas=False,
                 reclamos_frecuentes=False):
        self.nombre = nombre
        self.edad = edad
        self.enfermedades_cronicas = enfermedades_cronicas
        self.obesidad = obesidad
        self.estilo_vida_saludable = estilo_vida_saludable
        self.enfermedades_hereditarias = enfermedades_hereditarias
        self.fumador = fumador
        self.alcohol_excesivo = alcohol_excesivo
        self.deportista = deportista
        self.trabajo_alto_riesgo = trabajo_alto_riesgo
        self.polizas_previas_sin_problemas = polizas_previas_sin_problemas
        self.reclamos_frecuentes = reclamos_frecuentes
        self.puntos_riesgo = 0
        self.nivel_riesgo = None


# Definición de reglas para evaluar el riesgo
reglas = [
    # Reglas de edad
    {
        "condicion": Rule('edad < 30'),
        "efecto": -10,
        "descripcion": "Edad menor a 30 años"
    },
    {
        "condicion": Rule('edad >= 30 and edad <= 50'),
        "efecto": 0,
        "descripcion": "Edad entre 30 y 50 años"
    },
    {
        "condicion": Rule('edad > 50'),
        "efecto": 15,
        "descripcion": "Edad mayor a 50 años"
    },

    # Reglas de estado de salud
    {
        "condicion": Rule('enfermedades_cronicas == True'),
        "efecto": 20,
        "descripcion": "Presencia de enfermedades crónicas"
    },
    {
        "condicion": Rule('obesidad == True'),
        "efecto": 15,
        "descripcion": "Obesidad"
    },
    {
        "condicion": Rule('estilo_vida_saludable == True'),
        "efecto": -10,
        "descripcion": "Estilo de vida saludable"
    },

    # Reglas de historial médico familiar
    {
        "condicion": Rule('enfermedades_hereditarias == True'),
        "efecto": 15,
        "descripcion": "Enfermedades hereditarias en la familia"
    },

    # Reglas de estilo de vida
    {
        "condicion": Rule('fumador == True'),
        "efecto": 20,
        "descripcion": "Fumador"
    },
    {
        "condicion": Rule('alcohol_excesivo == True'),
        "efecto": 15,
        "descripcion": "Consumo excesivo de alcohol"
    },
    {
        "condicion": Rule('deportista == True'),
        "efecto": -15,
        "descripcion": "Práctica regular de deportes"
    },

    # Reglas de ocupación
    {
        "condicion": Rule('trabajo_alto_riesgo == True'),
        "efecto": 20,
        "descripcion": "Trabajo de alto riesgo"
    },

    # Reglas de historial de seguro
    {
        "condicion": Rule('polizas_previas_sin_problemas == True'),
        "efecto": -10,
        "descripcion": "Pólizas previas sin problemas"
    },
    {
        "condicion": Rule('reclamos_frecuentes == True'),
        "efecto": 15,
        "descripcion": "Historial de reclamos frecuentes"
    }
]


def evaluar_riesgo(cliente):
    """Evalúa el nivel de riesgo del cliente aplicando las reglas definidas"""
    factores_aplicados = []

    # Aplicar cada regla al cliente
    for regla in reglas:
        try:
            if regla["condicion"].evaluate(vars(cliente)):
                cliente.puntos_riesgo += regla["efecto"]
                factores_aplicados.append({
                    "descripcion": regla["descripcion"],
                    "efecto": regla["efecto"]
                })
        except Exception as e:
            print(f"Error al evaluar regla: {regla['descripcion']}")
            print(f"Error: {e}")

    # Determinar el nivel de riesgo basado en los puntos acumulados
    if cliente.puntos_riesgo < 10:
        cliente.nivel_riesgo = "Bajo"
        recomendacion = "Puede recibir la póliza sin problemas."
    elif cliente.puntos_riesgo < 30:
        cliente.nivel_riesgo = "Moderado"
        recomendacion = "Necesita exámenes adicionales antes de la aprobación."
    else:
        cliente.nivel_riesgo = "Alto"
        recomendacion = "La aseguradora rechaza la solicitud por alto riesgo."

    return {
        "nivel_riesgo": cliente.nivel_riesgo,
        "puntos_riesgo": cliente.puntos_riesgo,
        "factores_aplicados": factores_aplicados,
        "recomendacion": recomendacion
    }


def sistema_experto_interactivo():
    """Interfaz interactiva para el sistema experto"""
    print("Sistema Experto para Evaluación de Riesgo en Seguros de Vida")
    print("===========================================================")

    try:
        nombre = input("Nombre del cliente: ")

        edad = 0
        while edad <= 0:
            try:
                edad = int(input("Edad: "))
                if edad <= 0:
                    print("La edad debe ser un número positivo.")
            except ValueError:
                print("Error: La edad debe ser un número entero.")

        enfermedades_cronicas = input("¿Tiene enfermedades crónicas? (s/n): ").lower().startswith('s')
        obesidad = input("¿Tiene obesidad? (s/n): ").lower().startswith('s')
        estilo_vida_saludable = input("¿Mantiene un estilo de vida saludable? (s/n): ").lower().startswith('s')
        enfermedades_hereditarias = input(
            "¿Tiene antecedentes familiares de enfermedades hereditarias? (s/n): ").lower().startswith('s')
        fumador = input("¿Es fumador? (s/n): ").lower().startswith('s')
        alcohol_excesivo = input("¿Consume alcohol en exceso? (s/n): ").lower().startswith('s')
        deportista = input("¿Practica deportes regularmente? (s/n): ").lower().startswith('s')
        trabajo_alto_riesgo = input("¿Tiene un trabajo de alto riesgo? (s/n): ").lower().startswith('s')
        polizas_previas_sin_problemas = input("¿Ha tenido pólizas previas sin problemas? (s/n): ").lower().startswith(
            's')
        reclamos_frecuentes = input("¿Ha presentado reclamos frecuentes? (s/n): ").lower().startswith('s')

        cliente = Cliente(
            nombre, edad, enfermedades_cronicas, obesidad, estilo_vida_saludable,
            enfermedades_hereditarias, fumador, alcohol_excesivo, deportista,
            trabajo_alto_riesgo, polizas_previas_sin_problemas, reclamos_frecuentes
        )

        resultado = evaluar_riesgo(cliente)

        print("\nResultado de la Evaluación:")
        print(f"Cliente: {cliente.nombre}")
        print(f"Nivel de Riesgo: {resultado['nivel_riesgo']}")
        print(f"Puntos de Riesgo: {resultado['puntos_riesgo']}")
        print(f"Recomendación: {resultado['recomendacion']}")

        print("\nFactores que influyeron en la evaluación:")
        for factor in resultado['factores_aplicados']:
            signo = "+" if factor['efecto'] > 0 else ""
            print(f"  • {factor['descripcion']}: {signo}{factor['efecto']} puntos")

    except Exception as e:
        print(f"\nOcurrió un error inesperado: {e}")
        print("Por favor, contacte al soporte técnico si el problema persiste.")


# Modo de ejemplo para evitar errores de entrada interactiva
def ejemplo_sin_interaccion():
    """Ejecuta un ejemplo con valores predefinidos para comprobar el funcionamiento"""
    print("EJEMPLO DE FUNCIONAMIENTO (sin interacción):")
    print("============================================")

    # Crear un cliente de ejemplo
    cliente = Cliente(
        nombre="Juan Pérez",
        edad=45,
        enfermedades_cronicas=True,
        obesidad=False,
        estilo_vida_saludable=True,
        enfermedades_hereditarias=False,
        fumador=True,
        alcohol_excesivo=False,
        deportista=True,
        trabajo_alto_riesgo=False,
        polizas_previas_sin_problemas=True,
        reclamos_frecuentes=False
    )

    resultado = evaluar_riesgo(cliente)

    print("\nResultado de la Evaluación:")
    print(f"Cliente: {cliente.nombre}")
    print(f"Nivel de Riesgo: {resultado['nivel_riesgo']}")
    print(f"Puntos de Riesgo: {resultado['puntos_riesgo']}")
    print(f"Recomendación: {resultado['recomendacion']}")

    print("\nFactores que influyeron en la evaluación:")
    for factor in resultado['factores_aplicados']:
        signo = "+" if factor['efecto'] > 0 else ""
        print(f"  • {factor['descripcion']}: {signo}{factor['efecto']} puntos")


# Ejecutar el sistema
if __name__ == "__main__":
    # Descomentar para ejecutar en modo de ejemplo (sin interacción)
    # ejemplo_sin_interaccion()

    # Descomentar para ejecutar en modo interactivo
    sistema_experto_interactivo()